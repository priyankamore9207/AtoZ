export class OrderDetails
{
    orderId :number;
    toppings: String;
    price:number;
    orderDate:Date;

}