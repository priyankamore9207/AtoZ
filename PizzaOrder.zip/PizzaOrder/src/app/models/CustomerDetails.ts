export class CustomerDetails{
    customerName: String;
    mobileNumber: number;
    customerAddress: String;
}