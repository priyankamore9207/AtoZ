import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-display-order',
  templateUrl: './display-order.component.html',
  styleUrls: ['./display-order.component.css']
})
export class DisplayOrderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
