import { TestBed } from '@angular/core/testing';

import { DisplayorderService } from './displayorder.service';

describe('DisplayorderService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DisplayorderService = TestBed.get(DisplayorderService);
    expect(service).toBeTruthy();
  });
});
