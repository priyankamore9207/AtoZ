package com.cg.rest;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Album;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {

	@Autowired
	private AlbumService service;

	@PostMapping(path = "/save", consumes = "application/json")
	public String saveAlbum(@RequestBody Album a) {
		service.saveAlbum(a);
		return "Album saved";
	}

	@GetMapping("/all")
	public Iterable<Album> getAllAlbum() {
		return service.getAllAlbum();
	}

	@GetMapping(name = "/album", produces = "application/json")
	public Album getAlbum(@RequestParam("id") int id) {
		Album a = service.getById(id);
		return a;
	}

	@PutMapping(path = "/update/{id}", consumes = "application/json")
	public Album update(@PathVariable("id") int id, @RequestBody Album a) {
		return service.updateAlbum(a, id);
	}

	@DeleteMapping(path = "/delete/{id}")
	public String delete(@PathVariable("id") int id) {
		return service.deleteAlbum(id);
	}
	
	@GetMapping(path = "/alls/{id}")
	public ResponseEntity<Album> getOne(@PathVariable("id") int id) {
		try {
			Album a = service.getAlbum(id);
			return new ResponseEntity<Album>(a, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping(path = "/name/{title}")
	public Album getByName(@PathVariable("title") String title) {
		return service.findByTitle(title);
	}
}
