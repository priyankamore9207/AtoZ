    package com.cg.controller;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.User1;

//import org.springframework.beans.factory.annotation.Autowired;
//
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.cg.bean.User1;

@RestController
@RequestMapping("kafka")
public class Publisher {

	private KafkaTemplate<String, User1> kafkaTemplate;
	private String topic = "priyanka";

	@GetMapping("/publish/{name}")
	public String publishMessage(@PathVariable String name) {

		kafkaTemplate.send(topic, new User1(name, "123", "mumbai", "Grocery"));

		return "message published";
	}

//	@Autowired
//	private KafkaTemplate<String, User1> kafkaTemplate;
//
//	private String topic = "priyanka";
//
//	@GetMapping("/publish/{name}")
//	public String publishMessage(@PathVariable String name) {
//
//		kafkaTemplate.send(topic, new User1(name, "123", "mumbai", "Grocery"));
//
//		return "message published";
//	}

}
