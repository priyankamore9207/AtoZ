import { TestBed } from '@angular/core/testing';

import { AdminLoginCredentialsService } from './admin-login-credentials.service';

describe('AdminLoginCredentialsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdminLoginCredentialsService = TestBed.get(AdminLoginCredentialsService);
    expect(service).toBeTruthy();
  });
});
