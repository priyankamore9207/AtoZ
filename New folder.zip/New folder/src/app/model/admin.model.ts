export class AdminModel{
    empId: Number;
    empName: String;
    empMobile: Number;
    empSalary: Number;
    empLOP:  Number;
}