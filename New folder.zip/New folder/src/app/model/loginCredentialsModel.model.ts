export class LoginCredentialsModel{
    userName: String;
    password: String;
}