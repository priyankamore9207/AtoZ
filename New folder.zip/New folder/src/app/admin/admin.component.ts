import { Component, OnInit } from '@angular/core';
import { AdminModel } from '../model/admin.model';
import { Router } from '@angular/router';
import { AdminService } from '../services/admin.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
allAdmin: AdminModel[];
confirmationStatus;
  constructor(private router: Router, private adminService: AdminService) {
    this.allAdmin = [];
    this.allAdmin= this.adminService.viewEmployee();
   }

  ngOnInit() {
  }
  //   addEmployee() {
//     // navigate to home page on click of Go to Home button
//     this.router.navigate(['/create']);
//   }

deleteEmployee(index: number){
  this.confirmationStatus = confirm('Do you want to delete employee details?');
  if(this.confirmationStatus){
    this.adminService.deleteEmployee(index);
  }
}
}

//   addTask() {
//     // navigate to home page on click of Go to Home button
//     this.router.navigate(['/create']);
//   }
//   deleteTask(index: number) {
//     // ask user confirmation on delete
//     this.confirmationStatus = confirm('Do you want to delete the task?');
//     if (this.confirmationStatus) {
//       this.taskService.delete(index);
//     }
//   }
//   editTask(index: number) {
//     this.taskService.editTask(index);
//   }
// }
