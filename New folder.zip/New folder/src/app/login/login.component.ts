import { Component, OnInit } from '@angular/core';
import { LoginCredentialsModel } from '../model/loginCredentialsModel.model';
import { AdminLoginCredentialsService } from '../services/admin-login-credentials.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  input: LoginCredentialsModel;
  incorrectUserNameStatus: false;
  incorrectPasswordStatus: false;
  requiredUserNameStatus: false;
  requiredPasswordStatus: false;
  constructor(private roter: Router, private loginService: AdminLoginCredentialsService ) { 
    this.input = new LoginCredentialsModel();
    this.input.userName='';
    this.input.password='';
  }

  ngOnInit() {
  }
  
   validate() {
     // validates email
   if (this.input.userName !== '') {
     if(this.loginService.correctCredentials.userName !== this.input.userName){
        this.incorrectUserNameStatus = false;
        this.incorrectPasswordStatus = false;
     }
     else{
       this.requiredUserNameStatus = false;
     }
    // validates password
   if (this.input.password !== '') {
    if (this.loginService.correctCredentials.password !== this.input.password) {
      this.incorrectPasswordStatus = false;
      this.requiredPasswordStatus = false;
    }
   } else {
    this.requiredPasswordStatus = false;
   }
    // validates for correct credentials
    if (this.loginService.correctCredentials.userName === this.input.userName &&
      this.loginService.correctCredentials.password === this.input.password) {
        alert('Login successfull!');
      // this.router.navigate(['/admin']);
    this.roter.navigate(['/admin']);
    
    }
  }
  
}
clear(){
  this.input.userName = '';
  this.input.password = '';
  this.incorrectUserNameStatus = false;
  this.incorrectPasswordStatus = false;
  this.requiredUserNameStatus = false;
  this.requiredPasswordStatus = false;
}




}

// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { LoginService } from '../services/login.service';
// import { LoginCredentialsModel } from '../model/login-credentials-model';

// @Component({
//   selector: 'app-login',
//   templateUrl: './login.component.html',
//   styleUrls: ['./login.component.css']
// })
// export class LoginComponent implements OnInit {

//   input: LoginCredentialsModel;
//   incorrectEmailStatus = false;
//   incorrectPasswordStatus = false;
//   requiredEmailStatus = false;
//   requiredPasswordStatus = false;
//   constructor(private router: Router, private loginService: LoginService) {
//     this.input = new LoginCredentialsModel();
//     this.input.email = '';
//     this.input.password = '';
//   }

//   ngOnInit() {
//   }
//   navigateToHome() {
//      // navigate to home page on click of Go to Home button
//      this.router.navigate(['/home']);
//   }
//   validate() {
//     // validates email
//    if (this.input.email !== '') {
//     if (this.loginService.correctCredentials.email !== this.input.email) {
//       this.incorrectEmailStatus = true;
//       this.requiredEmailStatus = false;
//     }
//    } else {
//     this.requiredEmailStatus = true;
//    }
//    // validates password
//    if (this.input.password !== '') {
//     if (this.loginService.correctCredentials.password !== this.input.password) {
//       this.incorrectPasswordStatus = true;
//       this.requiredPasswordStatus = false;
//     }
//    } else {
//     this.requiredPasswordStatus = true;
//    }
//    // validates for correct credentials
//     if (this.loginService.correctCredentials.email === this.input.email &&
//       this.loginService.correctCredentials.password === this.input.password) {
//         alert('Login successfull!');
//         this.router.navigate(['/todo']);
//     }
//   }
//   clear() {
//     this.input.email = '';
//     this.input.password = '';
//     this.incorrectEmailStatus = false;
//     this.incorrectPasswordStatus = false;
//     this.requiredEmailStatus = false;
//     this.requiredPasswordStatus = false;
//   }
