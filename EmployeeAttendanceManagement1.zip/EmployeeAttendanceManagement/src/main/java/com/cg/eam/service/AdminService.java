package com.cg.eam.service;

import java.util.List;
import java.util.NoSuchElementException;

import com.cg.eam.entity.Admin;
import com.cg.eam.entity.Employee;

public interface AdminService {

	public String login(int id);

	public List<Employee> employeeList();

	public String addEmployee(Employee e);

	public String deleteEmployee(int id)throws NoSuchElementException;
	
	public Employee employeeDetails(int id);
	
	public String adminLogin(String userName,String password);
	
	public String addAdmin(Admin admin);
}
