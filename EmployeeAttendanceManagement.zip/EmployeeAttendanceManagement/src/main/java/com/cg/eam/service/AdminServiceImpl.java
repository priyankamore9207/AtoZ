package com.cg.eam.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.repo.EmployeeRepo;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {
	@Autowired
	private EmployeeRepo repo;

	@Autowired
	AdminStaffService adminStaffService;

	@Override
	public String login(int id) {
	Date date = new Date();
	System.out.println(date);
		
		 SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");  
		String formattedDate = formatter.format(date);
		System.out.println(formattedDate);
		if (repo.findById(id).isPresent()) {
			Attendance attendance= new Attendance();
			attendance.setDate(formattedDate);
			attendance.setStatus("Present");
			attendance.setId(id);
			adminStaffService.updateEmployeeAttendance(attendance);

			return "Present";
		} else
			return "Not Present";

	}

	@Override
	public List<Employee> employeeList() {

		return repo.findAll();
	}

	@Override
	public String addEmployee(Employee e) {

		Optional<Employee> res = repo.findById(e.getId());
		if (!res.isPresent()) {
			repo.save(e);
			return "Added";
		}
		System.out.println(res);

		return "Not Added";

	}

	@Override
	public String deleteEmployee(int id) throws NoSuchElementException {
		try {
			if (repo.findById(id).isPresent()) {
				repo.deleteById(id);
				return " Deleted";
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Album Record Found For Id " + id);
		}
		return "No Album Record Found For Id  " + id;
	}

	@Override
	public Employee employeeDetails(int id) {

		return repo.findById(id).get();
	}

}
