package com.cg.eam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.eam.entity.Employee;
import com.cg.eam.service.AdminService;

@RestController
public class AdminController {
	@Autowired
	private AdminService service;

	@GetMapping("/login/{id}")
	public String login(@PathVariable int id) {
		return service.login(id);

	}

	@PostMapping("/add")
	public String addEmployee(@RequestBody Employee e) {

		return service.addEmployee(e);

	}
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		return service.deleteEmployee(id);
		
	}
	
	@GetMapping("/getall")
	public List<Employee> employeeList(){
		return service.employeeList();
	}

	@GetMapping("/get/{id}")
	public Employee employeeDetails(@PathVariable int id) {
		return service.employeeDetails(id);
	}
}
