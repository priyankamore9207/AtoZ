package com.cg.eam.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.eam.entity.Attendance;
import com.cg.eam.entity.Employee;
import com.cg.eam.repo.AttendanceRepo;
import com.cg.eam.repo.EmployeeRepo;

@Service
@Transactional
public class AdminStaffServiceImpl implements AdminStaffService {
	@Autowired
	private AttendanceRepo repo;

	@Autowired
	private EmployeeRepo empRepo;

	@Override
	public int calculateLop(int id) {
		int count = repo.findByIdAndStatus(id, null).size();
		int countOfLeavesApplied = repo.findByIdAndStatus(id, "Leave").size();
		int totalCount = count + countOfLeavesApplied;
//		if(totalCount>8) {
		Optional<Employee> e = empRepo.findById(id);
//			int LOP= e.get().getSalary()-((e.get().getSalary()/30)/totalCount-8);
//			return LOP;
//		
		int oneDaySalary = (e.get().getSalary() / 30);
		int LOP = e.get().getSalary() - (oneDaySalary * totalCount);
		e.get().setLop(LOP);
		return LOP;
	}

	@Override
	public void updateEmployeeAttendance(Attendance attendance) {

		if (repo.findByDateAndId(attendance.getDate(), attendance.getId()).isPresent()) {

			System.out.println("Already came");

		} else {

//			Attendance attendance = new Attendance();
//			attendance.setDate(date);
//			attendance.setStatus(status);
//			attendance.setId(id);
			repo.save(attendance);
			System.out.println("saved");
		}
	}

	@Override
	public List<Attendance> employeeAttendance(int id) {
		List<Attendance> list = repo.findById(id);
		System.out.println(list);
		return list;
	}

}
