import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import {UserdetailService} from '../services/userdetail.service';
import {UserDetailModel} from '../model/userdetail';
@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
newuser: UserDetailModel;
  constructor(private router: Router, private userdetailService: UserdetailService ) {
     this.newuser = new UserDetailModel(); }
  ngOnInit() {
  }
  goBack() {
    this.router.navigate(['/userdetail']);
   }
   addUser() {
    this.userdetailService.add(this.newuser);
    }

}
