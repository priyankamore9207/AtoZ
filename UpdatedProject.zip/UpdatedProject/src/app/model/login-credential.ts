// tslint:disable-next-line:class-name
export class LoginCredentialsModel {
    email: string;
    password: string;
}

