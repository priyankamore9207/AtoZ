
export class UserDetailModel {
    firstname: string;
    lastname: string;
    email: string;
    id: number;

}

