import { Injectable } from '@angular/core';
import { LoginCredentialsModel } from '../model/login-credential';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  correctCredentials: LoginCredentialsModel;

  constructor() {
    // tslint:disable-next-line:new-parens
    this.correctCredentials = new LoginCredentialsModel;
    this.correctCredentials.email = 'admin@gmail.com';
    this.correctCredentials.password = '123456';

   }
}

