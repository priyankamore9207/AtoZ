import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import {UserDetailModel} from '../model/userdetail';

@Injectable({
  providedIn: 'root'
})
export class UserdetailService {
 // [userdetailArray: string]: any;
    userdetailArray: UserDetailModel[];
  constructor(private router: Router)  {
    this.userdetailArray = [];
   }
  add(user: UserDetailModel) {
    // add task to array
    user.id = Math.floor(Math.random() * 100);
    this.userdetailArray.push(user);
    this.router.navigate(['/userdetail']);
  }

  display() {
      // console.log(this.userdetailArray);
      return this.userdetailArray;
  }

  delete(index: number) {
  //  delete a particular task
       this.userdetailArray.splice(index, 1);
  }

  editUser(index: number) {
        // add id of task through route to prefill and edit particular task
    this.router.navigate(['/edit'], { queryParams: { id: index }});
  }

  getDetailsOf(index) {
       // get details of particular task
         return this.userdetailArray[index];
  }
  edit(index: number, updatedUserModel: UserDetailModel) {
          // update edited task details to array
         this.userdetailArray[index] = updatedUserModel;
         this.router.navigate(['/userdetail']);
        }
      }


