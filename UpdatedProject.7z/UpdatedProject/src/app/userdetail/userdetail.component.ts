import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {UserdetailService} from '../services/userdetail.service';
import {UserDetailModel} from '../model/userdetail';


@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
  allUsers: UserDetailModel[];
  confirmationStatus;
constructor(private router: Router, private userdetailService: UserdetailService) {
    this.allUsers = [];
    this.allUsers = this.userdetailService.display();
  }
  ngOnInit() {
    this.userdetailService.display();
  }
  goBack() {
        this.router.navigate(['/userdetail']);
       }
       addUser() {
          // navigate to home page on click of Go to Home button
          this.router.navigate(['/create']);
        }
          deleteUser(index: number) {
           // ask user confirmation on delete
             this.confirmationStatus = confirm('Do you want to delete the User Details?');
             if (this.confirmationStatus) {
              this.userdetailService.delete(index);
            }
          }
           editUser(index: number) {
           this.userdetailService.editUser(index);
         }
}



// import { Component, OnInit } from '@angular/core';
// import { Router } from '@angular/router';
// import { TaskModel } from '../model/task-model';
// import { TaskService } from '../services/task.service';

// @Component({
//   selector: 'app-todo',
//   templateUrl: './todo.component.html',
//   styleUrls: ['./todo.component.css']
// })
// export class TodoComponent implements OnInit {
//   allTasks: TaskModel[];
//   confirmationStatus;
//   constructor(private router: Router, private taskService: TaskService) {
//     this.allTasks = [];
//     this.allTasks = this.taskService.display();
//   }

//   ngOnInit() {
//   }
//   addTask() {
//     // navigate to home page on click of Go to Home button
//     this.router.navigate(['/create']);
//   }
//   deleteTask(index: number) {
//     // ask user confirmation on delete
//     this.confirmationStatus = confirm('Do you want to delete the task?');
//     if (this.confirmationStatus) {
//       this.taskService.delete(index);
//     }
//   }
//   editTask(index: number) {
//     this.taskService.editTask(index);
//   }
// }
