import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RoutesRecognized } from '@angular/router';
import {filter} from 'rxjs/operators';
import {UserDetailModel} from '../model/userdetail';
import {UserdetailService} from '../services/userdetail.service';
import { routerNgProbeToken } from '@angular/router/src/router_module';

@Component({
  selector: 'app-updateuser',
  templateUrl: './updateuser.component.html',
  styleUrls: ['./updateuser.component.css']
})
export class UpdateuserComponent implements OnInit {
  updatedUser: UserDetailModel;
  paramIndex;
 constructor(private route: ActivatedRoute, private router: Router, private userdetailService: UserdetailService) {
      this.updatedUser = new UserDetailModel();
  }

  ngOnInit() {
    if (window.location.search !== '') {
          // take id from route query param and prefill data of particular task
         this.route.queryParams.pipe(
           filter(params => params.id))
           .subscribe(params => {
            console.log(params.id);
            this.paramIndex = params.id;
            this.updatedUser = this.userdetailService.getDetailsOf(this.paramIndex);
             });
        }
  }
  updateUser() {
         // send index of user and updated details
        this.userdetailService.edit(this.paramIndex, this.updatedUser);
        this.router.navigate(['/userdetail']);
      }

}





// import { Component, OnInit } from '@angular/core';
// import { TaskModel } from '../model/task-model';
// import { ActivatedRoute, Router } from '@angular/router';
// import {filter} from 'rxjs/operators';
// import { TaskService } from '../services/task.service';
// @Component({
//   selector: 'app-updatetask',
//   templateUrl: './updatetask.component.html',
//   styleUrls: ['./updatetask.component.css']
// })
// export class UpdatetaskComponent implements OnInit {
//   updatedTask: TaskModel;
//   paramIndex;
//   constructor(private route: ActivatedRoute, private router: Router, private taskService: TaskService) {
//     this.updatedTask = new TaskModel();
//   }

//   ngOnInit() {
//     if (window.location.search !== '') {
//       // take id from route query param and prefill data of particular task
//       this.route.queryParams.pipe(
//       filter(params => params.id))
//       .subscribe(params => {
//       console.log(params.id);
//       this.paramIndex = params.id;
//       this.updatedTask = this.taskService.getDetailsOf(this.paramIndex);
//       });
//     }
//   }
//   updateTask() {
//     // send index of task and updated details
//     this.taskService.edit(this.paramIndex, this.updatedTask);
//   }
// }
