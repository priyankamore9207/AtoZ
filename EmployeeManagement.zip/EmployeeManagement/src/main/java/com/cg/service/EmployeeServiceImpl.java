package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepo repo;

	@Override
	public void saveEmployee(Employee e) {
		repo.save(e);

	}

	@Override
	public Iterable<Employee> getAllEmployee() {

		return repo.findAll();
	}

	@Override
	public Employee getById(int id) {

		return repo.findById(id).get();
	}

	@Override
	public Employee updateEmployee(Employee e, int id) {
		e.setEmployeeId(id);
		repo.save(e);
		return e;
	}

	@Override
	public String deleteEmployee(int id) {
		Employee e1 = repo.findById(id).get();
		repo.delete(e1);
		return "Employee Record Deleted Successfully";
	}

	@Override
	public String findByFirstName(String firstName) {

		return ((EmployeeServiceImpl) repo).findByFirstName(firstName);
	}

	@Override
	public String findByLastName(String lastName) {

		return ((EmployeeServiceImpl) repo).findByLastName(lastName);
	}

}
