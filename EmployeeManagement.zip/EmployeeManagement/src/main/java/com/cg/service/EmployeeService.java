package com.cg.service;

import com.cg.entity.Employee;

public interface EmployeeService {
	public void saveEmployee(Employee e);

	public Iterable<Employee> getAllEmployee();

	public Employee getById(int id);

	public Employee updateEmployee(Employee e, int id);

	public String deleteEmployee(int id);

	public String findByFirstName(String firstName);

	public String findByLastName(String lastName);

}
