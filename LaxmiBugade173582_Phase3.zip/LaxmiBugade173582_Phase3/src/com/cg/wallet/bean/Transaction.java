package com.cg.wallet.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Transaction")
public class Transaction {

	//declaring constants
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long transId;
	private long custId;
	private String type;
	private String balance;
	
	//Getters and setters
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getCustId() {
		return custId;
	}
	public void setCustId(long custId) {
		this.custId = custId;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	
	//Costructors
	public Transaction(){}
	
	public Transaction(long custId, String type, String balance) {
		this.custId = custId;
		this.type = type;
		this.balance = balance;
	}
	
	
	//toString method
	@Override
	public String toString() {
		return "Customer Id="+getCustId()+"\tType="+getType()+"\tBalance="+getBalance();
	}
}
