package com.cg.wallet.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.wallet.bean.Customer;

public class TestAccount {

private static EntityManager mgr;
	
	@BeforeClass
	public static void init(){
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		mgr = factory.createEntityManager();
	}
	
	@Before
	public void start(){
		mgr.getTransaction().begin();
	}
	
	@After
	public void stop(){
		mgr.getTransaction().commit();
	}
	
	@Test
	public void testShowBalance(){
		Customer c = (Customer)mgr.find(Customer.class, 82);
		System.out.println(c.getBalance());
	}
	
	@Test
	public void addCustomer(){
//		Department dept = (Department)mgr.find(Department.class, 10);
		
		Customer c = new Customer();
		c.setName("Pranjal");
		c.setEmail("pranjal@gmail.com");
		c.setMobile("9587463210");
		mgr.persist(c);
		mgr.close();
	}
	
	@AfterClass
	public static void flush(){
		mgr.close();
	}
}
